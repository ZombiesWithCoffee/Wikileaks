﻿using mshtml;

namespace WikiLeaks.Abstract {
    public interface ICssStyle {
        void Update(HTMLDocument document);
    }

}
