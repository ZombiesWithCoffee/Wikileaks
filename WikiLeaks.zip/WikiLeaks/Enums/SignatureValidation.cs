﻿namespace WikiLeaks.Enums {
    public enum SignatureValidation {
        NoSignature,
        NoPublicKey,
        Invalid,
        Valid
    }
}
