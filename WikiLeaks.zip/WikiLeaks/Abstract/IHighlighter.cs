﻿namespace WikiLeaks.Services{
    public interface IHighlighter{
        string HighlightSearchTerms(string text);
    }
}